# visualize all puzzles
import json
import rushhour
import os, shutil

ins_file = '/Users/chloe/Documents/RushHour/exp_data/data_adopted/'
out_file = '/Users/chloe/Documents/RushHour/puzzle_figures/'
# sorted according to optimal length
all_instances = ['prb8786', 'prb11647', 'prb21272', 'prb13171', 'prb1707', 'prb23259', 'prb10206', 'prb2834', 'prb28111', 'prb32795', 'prb26567', 'prb14047', 'prb14651', 'prb32695', 'prb29232', 'prb15290', 'prb12604', 'prb20059', 'prb9718', 'prb29414', 'prb22436', 'prb62015', 'prb38526', 'prb3217', 'prb34092', 'prb12715', 'prb54081', 'prb717', 'prb31907', 'prb42959', 'prb79230', 'prb14898', 'prb62222', 'prb68910', 'prb33509', 'prb46224', 'prb47495', 'prb29585', 'prb38725', 'prb33117', 'prb20888', 'prb55384', 'prb6671', 'prb343', 'prb68514', 'prb29600', 'prb23404', 'prb19279', 'prb3203', 'prb65535', 'prb14485', 'prb34551', 'prb72800', 'prb44171', 'prb1267', 'prb29027', 'prb24406', 'prb58853', 'prb24227', 'prb45893', 'prb25861', 'prb15595', 'prb54506', 'prb48146', 'prb78361', 'prb25604', 'prb46639', 'prb46580', 'prb10166', 'prb57223']

# iterate through all instances
for instance in all_instances:
	ins_json_file = ins_file + instance + '.json'
	cur_ins = rushhour.json_to_ins(ins_json_file)
	# # make instance directory
	ins_dir = out_file + instance + '/'
	if not os.path.exists(ins_dir):
		os.mkdir(ins_dir)
    # save current drawing in this dir
	ins_vis_dir = ins_dir+ instance + '.txt'
	rushhour.draw_save(cur_ins, ins_vis_dir)