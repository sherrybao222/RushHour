from sys import argv
from analyze import *

paths(argv[1])
