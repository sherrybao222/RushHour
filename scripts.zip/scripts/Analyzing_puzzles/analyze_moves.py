from sys import argv
from analyze import *

moves_psiturk(argv[1],argv[2])
