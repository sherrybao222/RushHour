from sys import argv
from analyze import *


psiturk_paths(argv[1])
