def test():
	print(233)